import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        // Crear hotel
        Hotel hotel = new Hotel("Hotel Moderno");

        // Agregar habitaciones
        hotel.agregarHabitacion(new Habitacion(101, 2));
        hotel.agregarHabitacion(new Habitacion(102, 4));
        hotel.agregarHabitacion(new Habitacion(103, 1));

        // Mostrar habitaciones
        System.out.println("Bienvenido al sistema de reservas del " + hotel.getNombre());
        System.out.println("Estas son las habitaciones disponibles inicialmente:");
        hotel.mostrarHabitaciones();

        // Ingreso de datos para la reserva
        System.out.print("\nIngrese la cantidad de huéspedes: ");
        int numeroHuespedes = scanner.nextInt();
        scanner.nextLine(); // Consumir la nueva línea

        Habitacion habitacionDisponible = hotel.buscarHabitacionDisponible(numeroHuespedes);

        if (habitacionDisponible != null) {
            System.out.println("Habitación disponible: " + habitacionDisponible.getNumero());
            System.out.print("Ingrese el nombre del huésped: ");
            String nombreHuesped = scanner.nextLine();

            LocalDate fechaInicio = null;
            LocalDate fechaFin = null;

            while (true) {
                try {
                    System.out.print("Ingrese la fecha de inicio de la reserva (dd/MM/yyyy): ");
                    fechaInicio = LocalDate.parse(scanner.nextLine(), formatter);
                    break;
                } catch (DateTimeParseException e) {
                    System.out.println("Formato de fecha inválido. Intente de nuevo.");
                }
            }

            while (true) {
                try {
                    System.out.print("Ingrese la fecha de fin de la reserva (dd/MM/yyyy): ");
                    fechaFin = LocalDate.parse(scanner.nextLine(), formatter);
                    if (fechaFin.isAfter(fechaInicio)) {
                        break;
                    } else {
                        System.out.println("La fecha de fin debe ser posterior a la fecha de inicio. Intente de nuevo.");
                    }
                } catch (DateTimeParseException e) {
                    System.out.println("Formato de fecha inválido. Intente de nuevo.");
                }
            }

            // Crear reserva
            Reserva reserva = new Reserva(nombreHuesped, fechaInicio, fechaFin, habitacionDisponible);
            System.out.println("\nReserva realizada exitosamente:");
            System.out.println(reserva);

            // Mostrar estado de las habitaciones
            System.out.println("\nEstado de las habitaciones después de la reserva:");
            hotel.mostrarHabitaciones();

            // Cancelar la reserva
            System.out.print("\n¿Desea cancelar la reserva? (si/no): ");
            String cancelar = scanner.nextLine();

            if (cancelar.equalsIgnoreCase("si")) {
                reserva.cancelar();
                System.out.println("La reserva ha sido cancelada.");
                System.out.println("\nEstado de las habitaciones después de cancelar la reserva:");
                hotel.mostrarHabitaciones();
            } else {
                System.out.println("Gracias por usar nuestro sistema.");
            }
        } else {
            System.out.println("No hay habitaciones disponibles para " + numeroHuespedes + " huéspedes.");
        }

        scanner.close();
    }
}
