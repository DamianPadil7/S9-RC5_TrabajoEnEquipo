import java.util.ArrayList;
import java.util.List;

public class Hotel {
    private String nombre;
    private List<Habitacion> habitaciones;

    public Hotel(String nombre) {
        this.nombre = nombre;
        this.habitaciones = new ArrayList<>();
    }

    public void agregarHabitacion(Habitacion habitacion) {
        habitaciones.add(habitacion);
    }

    public Habitacion buscarHabitacionDisponible(int capacidadRequerida) {
        for (Habitacion habitacion : habitaciones) {
            if (habitacion.isDisponible() && habitacion.getCapacidad() >= capacidadRequerida) {
                return habitacion;
            }
        }
        return null;
    }

    public void mostrarHabitaciones() {
        for (Habitacion habitacion : habitaciones) {
            System.out.println(habitacion);
        }
    }

    // Getters
    public String getNombre() {
        return nombre;
    }
}
