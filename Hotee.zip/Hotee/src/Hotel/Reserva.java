import java.time.LocalDate;

public class Reserva {
    private String huesped;
    private LocalDate fechaInicio;
    private LocalDate fechaFin;
    private Habitacion habitacion;

    public Reserva(String huesped, LocalDate fechaInicio, LocalDate fechaFin, Habitacion habitacion) {
        this.huesped = huesped;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.habitacion = habitacion;
        habitacion.reservar(); // Marcar habitación como reservada
    }

    public void cancelar() {
        habitacion.liberar();
    }

    @Override
    public String toString() {
        return "Reserva de " + huesped + " en la habitación " + habitacion.getNumero() +
                " desde " + fechaInicio + " hasta " + fechaFin;
    }

    // Getters
    public String getHuesped() {
        return huesped;
    }

    public LocalDate getFechaInicio() {
        return fechaInicio;
    }

    public LocalDate getFechaFin() {
        return fechaFin;
    }

    public Habitacion getHabitacion() {
        return habitacion;
    }
}
