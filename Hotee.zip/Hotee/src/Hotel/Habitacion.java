public class Habitacion {
    private int numero;
    private int capacidad;
    private boolean disponible;

    public Habitacion(int numero, int capacidad) {
        this.numero = numero;
        this.capacidad = capacidad;
        this.disponible = true;
    }

    public void reservar() {
        if (disponible) {
            disponible = false;
        } else {
            System.out.println("La habitación " + numero + " ya está reservada.");
        }
    }

    public void liberar() {
        disponible = true;
    }

    @Override
    public String toString() {
        return "Habitación " + numero + " (Capacidad: " + capacidad + ", Disponible: " + disponible + ")";
    }

    // Getters y Setters
    public int getNumero() {
        return numero;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public boolean isDisponible() {
        return disponible;
    }
}
